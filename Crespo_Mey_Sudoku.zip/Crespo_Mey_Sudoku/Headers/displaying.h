#ifndef _DISPLAYING_
#define _DISPLAYING_

#include "sudoku.h"
#include "sudoku.h"
#include <stdio.h>

void simpleDisplay(Sudoku);
void Display(Sudoku);


#endif // DISPLAYING
