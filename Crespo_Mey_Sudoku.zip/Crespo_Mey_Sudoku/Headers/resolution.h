#ifndef _RESOLUTION_
#define _RESOLUTION_

#include "sudoku.h"
#include "utils.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void backtracking(Sudoku);


#endif // RESOLUTION
